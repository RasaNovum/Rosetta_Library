package net.rasanovum.rosetta.util;

import net.minecraft.resources.Identifier;

/** Identifier and registry helpers. */
public final class RegistryCompat {
    private RegistryCompat() {}

    public static Identifier getLocation(String location) {
        //? if <1.21 {
        /*return new Identifier(location);
        *///?} else {
        return Identifier.parse(location);
        //?}
    }

    public static Identifier getLocation(String base, String path) {
        //? if <1.21 {
        /*return new Identifier(base, path);
        *///?} else {
        return Identifier.parse(base + ":" + path);
        //?}
    }

    public static net.minecraft.world.level.block.state.BlockBehaviour.Properties blockProperties(
            Identifier id,
            net.minecraft.world.level.block.state.BlockBehaviour.Properties properties
    ) {
        //? if >=26.1 {
        return properties.setId(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.BLOCK, id));
        //?} else {
        /*return properties;
        *///?}
    }

    public static net.minecraft.world.item.Item.Properties itemProperties(
            Identifier id,
            net.minecraft.world.item.Item.Properties properties
    ) {
        //? if >=26.1 {
        return properties.setId(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.ITEM, id));
        //?} else {
        /*return properties;
        *///?}
    }

    public static <T> T registryGet(net.minecraft.core.Registry<T> registry, Identifier id) {
        //? if >=26.1 {
        return registry.getValue(id);
        //?} else {
        /*return registry.get(id);
        *///?}
    }

    public static Identifier keyLocation(net.minecraft.resources.ResourceKey<?> key) {
        //? if >=26.1 {
        return key.identifier();
        //?} else {
        /*return key.location();
        *///?}
    }
}
