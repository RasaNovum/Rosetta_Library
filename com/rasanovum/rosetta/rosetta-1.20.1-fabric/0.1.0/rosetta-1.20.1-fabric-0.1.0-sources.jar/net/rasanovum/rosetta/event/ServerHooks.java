package net.rasanovum.rosetta.event;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.class_1936;
import net.minecraft.class_2168;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/** Loader-neutral server lifecycle hooks. Register callbacks during mod initialization. */
public final class ServerHooks {
    private static final List<Callbacks> CALLBACKS = new CopyOnWriteArrayList<>();

    private ServerHooks() {}

    public static void register(Callbacks callbacks) {
        if (callbacks == null) throw new IllegalArgumentException("callbacks cannot be null");
        CALLBACKS.add(callbacks);
    }

    public static void playerJoined(class_3222 player) { CALLBACKS.forEach(c -> c.onPlayerJoin(player)); }
    public static void playerLeft(class_3222 player) { CALLBACKS.forEach(c -> c.onPlayerLeave(player)); }
    public static void serverLevelTick(class_3218 level) { CALLBACKS.forEach(c -> c.onServerLevelTick(level)); }
    public static void serverStarting(MinecraftServer server) { CALLBACKS.forEach(c -> c.onServerStarting(server)); }
    public static void serverStarted(MinecraftServer server) { CALLBACKS.forEach(c -> c.onServerStarted(server)); }
    public static void serverStopping(MinecraftServer server) { CALLBACKS.forEach(c -> c.onServerStopping(server)); }
    public static void dataPackReloaded(MinecraftServer server) { CALLBACKS.forEach(c -> c.onDataPackReload(server)); }
    public static void playerChangedDimension(class_3222 player) { CALLBACKS.forEach(c -> c.onPlayerChangedDimension(player)); }
    public static void registerCommands(CommandDispatcher<class_2168> dispatcher) { CALLBACKS.forEach(c -> c.registerCommands(dispatcher)); }

    public static boolean beforeBlockBreak(class_1936 level, class_2338 pos, class_3222 player) {
        boolean allowed = true;
        for (Callbacks callbacks : CALLBACKS) allowed &= callbacks.beforeBlockBreak(level, pos, player);
        return allowed;
    }

    public interface Callbacks {
        default void onPlayerJoin(class_3222 player) {}
        default void onPlayerLeave(class_3222 player) {}
        default void onServerLevelTick(class_3218 level) {}
        default void onServerStarting(MinecraftServer server) {}
        default void onServerStarted(MinecraftServer server) {}
        default void onServerStopping(MinecraftServer server) {}
        default void onDataPackReload(MinecraftServer server) {}
        default void onPlayerChangedDimension(class_3222 player) {}
        default boolean beforeBlockBreak(class_1936 level, class_2338 pos, class_3222 player) { return true; }
        default void registerCommands(CommandDispatcher<class_2168> dispatcher) {}
    }
}
