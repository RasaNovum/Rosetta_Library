package net.rasanovum.rosetta.registry;

import java.util.function.Supplier;
import net.minecraft.class_2960;

/** Stable access to a value whose loader controls when it becomes available. */
public interface RegistryHandle<T> extends Supplier<T> {
    class_2960 id();
}
