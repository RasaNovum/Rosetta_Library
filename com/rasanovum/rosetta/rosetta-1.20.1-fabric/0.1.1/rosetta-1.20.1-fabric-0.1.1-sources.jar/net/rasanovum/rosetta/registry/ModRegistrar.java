package net.rasanovum.rosetta.registry;

import net.rasanovum.rosetta.util.RegistryCompat;

//? if forge {
/*import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.registries.DeferredRegister;
*///?} else if neoforge {
/*import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredRegister;
*///?}

//? if >=26.1 && fabric {
/*import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
*///?} else if fabric {
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
//?}
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;

//? if >=26.1 && fabric {
/*import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
*///?}

import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.BiFunction;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * Per-mod registry facade. Declare values first, then attach the registrar once
 * from the loader entrypoint.
 */
public final class ModRegistrar {
    private final String namespace;
    private final Map<class_2378<?>, Set<String>> paths = new LinkedHashMap<>();
    private final Map<class_5321<class_1761>, CreativeTabEntries> creativeTabs = new LinkedHashMap<>();
    //? if fabric {
    private final List<FabricRegistration<?>> fabricRegistrations = new ArrayList<>();
    //?} else {
    /*private final Map<Registry<?>, DeferredRegister<?>> deferredRegisters = new LinkedHashMap<>();
    *///?}
    private State state = State.DECLARING;

    public ModRegistrar(String namespace) {
        this.namespace = Objects.requireNonNull(namespace, "namespace");
        RegistryCompat.getLocation(namespace, "registration_probe");
    }

    public String namespace() {
        return namespace;
    }

    /** Register any value in a vanilla registry. */
    public <T, I extends T> RegistryHandle<I> register(
            class_2378<T> registry,
            String path,
            Supplier<? extends I> factory
    ) {
        requireDeclaring();
        Objects.requireNonNull(registry, "registry");
        Objects.requireNonNull(factory, "factory");
        class_2960 id = id(path);
        Supplier<I> checkedFactory = () -> Objects.requireNonNull(factory.get(),
                "Factory for '" + id + "' returned null");
        Set<String> registryPaths = paths.computeIfAbsent(registry, ignored -> new LinkedHashSet<>());
        if (!registryPaths.add(path)) {
            throw new IllegalArgumentException("Duplicate registration '" + id + "' in registry '"
                    + RegistryCompat.keyLocation(registry.method_30517()) + "'");
        }

        Handle<I> handle = new Handle<>(id);
        //? if fabric {
        fabricRegistrations.add(new FabricRegistration<>(registry, handle, checkedFactory));
        //?} else if forge {
        /*DeferredRegister<T> deferred = deferredRegister(registry);
        var holder = deferred.register(path, checkedFactory);
        handle.bind(holder, holder::isPresent);
        *///?} else if neoforge {
        /*DeferredRegister<T> deferred = deferredRegister(registry);
        var holder = deferred.register(path, checkedFactory);
        handle.bind(holder, holder::isBound);
        *///?}
        return handle;
    }

    public <B extends class_2248> RegistryHandle<B> block(
            String path,
            Function<class_4970.class_2251, ? extends B> factory,
            class_4970.class_2251 properties
    ) {
        class_2960 id = id(path);
        return register(class_7923.field_41175, path,
                () -> factory.apply(RegistryCompat.blockProperties(id, properties)));
    }

    public <I extends class_1792> RegistryHandle<I> item(
            String path,
            Function<class_1792.class_1793, ? extends I> factory,
            class_1792.class_1793 properties
    ) {
        class_2960 id = id(path);
        return register(class_7923.field_41178, path,
                () -> factory.apply(RegistryCompat.itemProperties(id, properties)));
    }

    /** Declare entries for an existing creative tab. Repeated calls for the same tab share one ordered list. */
    public CreativeTabEntries creativeTab(class_5321<class_1761> tab) {
        requireCreativeDeclaring(tab);
        return creativeTabs.computeIfAbsent(tab, CreativeTabEntries::new);
    }

    public <B extends class_2248> BlockItemEntry<B, class_1747> blockWithItem(
            String path,
            Function<class_4970.class_2251, ? extends B> blockFactory,
            class_4970.class_2251 blockProperties,
            class_1792.class_1793 itemProperties
    ) {
        return blockWithItem(path, blockFactory, blockProperties, class_1747::new, itemProperties);
    }

    public <B extends class_2248, I extends class_1747> BlockItemEntry<B, I> blockWithItem(
            String path,
            Function<class_4970.class_2251, ? extends B> blockFactory,
            class_4970.class_2251 blockProperties,
            BiFunction<? super B, class_1792.class_1793, ? extends I> itemFactory,
            class_1792.class_1793 itemProperties
    ) {
        RegistryHandle<B> block = block(path, blockFactory, blockProperties);
        class_2960 id = id(path);
        RegistryHandle<I> item = register(class_7923.field_41178, path,
                () -> itemFactory.apply(block.get(), RegistryCompat.itemProperties(id, itemProperties)));
        return new BlockItemEntry<>(block, item);
    }

    @SafeVarargs
    public final <T extends class_2586> RegistryHandle<class_2591<T>> blockEntity(
            String path,
            BlockEntityFactory<T> factory,
            RegistryHandle<? extends class_2248>... validBlocks
    ) {
        Objects.requireNonNull(factory, "factory");
        Objects.requireNonNull(validBlocks, "validBlocks");
        if (validBlocks.length == 0) {
            throw new IllegalArgumentException("Block entity type '" + id(path) + "' needs at least one valid block");
        }
        RegistryHandle<? extends class_2248>[] blocks = validBlocks.clone();
        for (RegistryHandle<? extends class_2248> block : blocks) Objects.requireNonNull(block, "validBlocks");
        return register(class_7923.field_41181, path, () -> createBlockEntityType(factory, blocks));
    }

    /** Attach all declared registries. This operation is deliberately one-shot. */
    public void register(RegistrationContext context) {
        Objects.requireNonNull(context, "context");
        if (state != State.DECLARING) {
            throw new IllegalStateException("Registrar for '" + namespace + "' was already attached");
        }
        state = State.ATTACHING;
        try {
            //? if >=26.1 && fabric {
            /*for (FabricRegistration<?> registration : fabricRegistrations) registration.register();
            for (CreativeTabEntries entries : creativeTabs.values()) {
                CreativeModeTabEvents.modifyOutputEvent(entries.tab).register(entries::accept);
            }
            *///?} else if fabric {
            for (FabricRegistration<?> registration : fabricRegistrations) registration.register();
            for (CreativeTabEntries entries : creativeTabs.values()) {
                ItemGroupEvents.modifyEntriesEvent(entries.tab).register(entries::accept);
            }
            //?} else {
            /*for (DeferredRegister<?> deferred : deferredRegisters.values()) deferred.register(context.eventBus());
            if (!creativeTabs.isEmpty()) context.eventBus().addListener(this::addCreativeTabContents);
            *///?}
            state = State.ATTACHED;
        } catch (RuntimeException exception) {
            state = State.FAILED;
            throw exception;
        }
    }

    private class_2960 id(String path) {
        Objects.requireNonNull(path, "path");
        if (path.indexOf(':') >= 0) {
            throw new IllegalArgumentException("Registration paths are relative to namespace '" + namespace
                    + "'; use '" + path.substring(path.indexOf(':') + 1) + "' instead of '" + path + "'");
        }
        return RegistryCompat.getLocation(namespace, path);
    }

    private void requireDeclaring() {
        if (state != State.DECLARING) {
            throw new IllegalStateException("Cannot add registrations to '" + namespace + "' after attachment started");
        }
    }

    private void requireCreativeDeclaring(class_5321<class_1761> tab) {
        Objects.requireNonNull(tab, "tab");
        if (state != State.DECLARING) {
            throw new IllegalStateException("Cannot add entries to creative tab '"
                    + RegistryCompat.keyLocation(tab) + "' after registrar '" + namespace + "' attachment started");
        }
    }

    //? if forge || neoforge {
    /*private void addCreativeTabContents(BuildCreativeModeTabContentsEvent event) {
        CreativeTabEntries entries = creativeTabs.get(event.getTabKey());
        if (entries != null) entries.accept(event);
    }
    *///?}

    //? if forge || neoforge {
    /*@SuppressWarnings("unchecked")
    private <T> DeferredRegister<T> deferredRegister(Registry<T> registry) {
        return (DeferredRegister<T>) deferredRegisters.computeIfAbsent(registry,
                key -> DeferredRegister.create(registry.key(), namespace));
    }
    *///?}

    private static <T extends class_2586> class_2591<T> createBlockEntityType(
            BlockEntityFactory<T> factory,
            RegistryHandle<? extends class_2248>[] handles
    ) {
        class_2248[] blocks = new class_2248[handles.length];
        for (int i = 0; i < handles.length; i++) blocks[i] = handles[i].get();
        //? if >=26.1 && fabric {
        /*return FabricBlockEntityTypeBuilder.create(factory::create, blocks).build();
        *///?} else if >=26.1 && neoforge {
        /*return new BlockEntityType<>(factory::create, Set.of(blocks));
        *///?} else {
        return class_2591.class_2592.method_20528(factory::create, blocks).method_11034(null);
        //?}
    }

    public record BlockItemEntry<B extends class_2248, I extends class_1747>(
            RegistryHandle<B> block,
            RegistryHandle<I> item
    ) {}

    /** Ordered entries for one vanilla creative tab. */
    public final class CreativeTabEntries {
        private final class_5321<class_1761> tab;
        private final List<Consumer<class_1761.class_7704>> callbacks = new ArrayList<>();
        private final Set<class_2960> handles = new LinkedHashSet<>();
        private final Set<class_1792> items = Collections.newSetFromMap(new IdentityHashMap<>());
        private final Set<String> callbackKeys = new LinkedHashSet<>();

        private CreativeTabEntries(class_5321<class_1761> tab) {
            this.tab = tab;
        }

        public CreativeTabEntries add(RegistryHandle<? extends class_1935> handle) {
            requireCreativeDeclaring(tab);
            Objects.requireNonNull(handle, "handle");
            if (!handles.add(handle.id())) {
                throw duplicate("registry handle '" + handle.id() + "'");
            }
            callbacks.add(output -> output.method_45421(handle.get()));
            return this;
        }

        public CreativeTabEntries add(BlockItemEntry<?, ?> entry) {
            Objects.requireNonNull(entry, "entry");
            return add(entry.item());
        }

        public CreativeTabEntries add(class_1935 item) {
            requireCreativeDeclaring(tab);
            Objects.requireNonNull(item, "item");
            class_1792 value = item.method_8389();
            if (!items.add(value)) {
                throw duplicate("item '" + value + "'");
            }
            callbacks.add(output -> output.method_45421(value));
            return this;
        }

        /** Add one freshly-created stack each time creative-tab contents are rebuilt. */
        public CreativeTabEntries addStack(String key, Supplier<class_1799> stack) {
            Objects.requireNonNull(stack, "stack");
            return addStacks(key, output -> output.method_45420(Objects.requireNonNull(stack.get(),
                    "Creative-tab stack callback '" + id(key) + "' returned null")));
        }

        /** Add any number of dynamic stacks through the vanilla output interface. */
        public CreativeTabEntries addStacks(String key, Consumer<class_1761.class_7704> callback) {
            requireCreativeDeclaring(tab);
            Objects.requireNonNull(callback, "callback");
            class_2960 callbackId = id(key);
            if (!callbackKeys.add(key)) {
                throw duplicate("callback '" + callbackId + "'");
            }
            callbacks.add(callback);
            return this;
        }

        private void accept(class_1761.class_7704 output) {
            for (Consumer<class_1761.class_7704> callback : callbacks) callback.accept(output);
        }

        private IllegalArgumentException duplicate(String entry) {
            return new IllegalArgumentException("Duplicate creative-tab " + entry + " for tab '"
                    + RegistryCompat.keyLocation(tab) + "'");
        }
    }

    @FunctionalInterface
    public interface BlockEntityFactory<T extends class_2586> {
        T create(class_2338 position, class_2680 state);
    }

    private enum State { DECLARING, ATTACHING, ATTACHED, FAILED }

    private static final class Handle<T> implements RegistryHandle<T> {
        private final class_2960 id;
        private Supplier<? extends T> delegate;
        private BooleanSupplier ready;

        private Handle(class_2960 id) {
            this.id = id;
        }

        private void bind(Supplier<? extends T> delegate) {
            bind(delegate, () -> true);
        }

        private void bind(Supplier<? extends T> delegate, BooleanSupplier ready) {
            this.delegate = Objects.requireNonNull(delegate, "delegate");
            this.ready = Objects.requireNonNull(ready, "ready");
        }

        @Override
        public class_2960 id() {
            return id;
        }

        @Override
        public T get() {
            if (delegate == null || !ready.getAsBoolean()) throw notReady();
            T value = delegate.get();
            if (value == null) {
                throw new IllegalStateException("Registry provider for '" + id
                        + "' returned null after reporting that the value was ready");
            }
            return value;
        }

        private IllegalStateException notReady() {
            return new IllegalStateException("Registry value '" + id
                    + "' is not available yet; access it after its registry event has completed");
        }
    }

    //? if fabric {
    private record FabricRegistration<T>(
            class_2378<? super T> registry,
            Handle<T> handle,
            Supplier<? extends T> factory
    ) {
        private void register() {
            T value = Objects.requireNonNull(factory.get(), "Factory for '" + handle.id() + "' returned null");
            T registered = class_2378.method_10230(registry, handle.id(), value);
            handle.bind(() -> registered);
        }
    }
    //?}
}
