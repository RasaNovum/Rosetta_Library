package net.rasanovum.rosetta.loaders.fabric.mixin;

import org.apache.commons.lang3.mutable.MutableObject;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.class_1923;
import net.minecraft.class_2672;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.rasanovum.rosetta.event.ServerHooks;

@Mixin(targets = "net.minecraft.server.level.ChunkMap")
public abstract class ChunkMapTrackingMixin {
    @Shadow @Final private class_3218 level;

    //? if <1.21 {
    
    @Inject(method = "playerLoadedChunk", at = @At("RETURN"))
    private void rosetta$chunkSent(class_3222 player,
                                    MutableObject<class_2672> packetCache,
                                    class_2818 chunk, CallbackInfo callbackInfo) {
        ServerHooks.chunkSent(player, level, chunk);
    }

    @Inject(
            method = "updateChunkTracking",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/server/level/ServerPlayer;untrackChunk(Lnet/minecraft/world/level/ChunkPos;)V",
                    shift = At.Shift.AFTER))
    private void rosetta$chunkUnwatched(class_3222 player, class_1923 pos,
                                         MutableObject<class_2672> packetCache,
                                         boolean wasLoaded, boolean load, CallbackInfo callbackInfo) {
        ServerHooks.chunkUnwatched(player, level, pos);
    }
    //?} else {
    //?}
}
