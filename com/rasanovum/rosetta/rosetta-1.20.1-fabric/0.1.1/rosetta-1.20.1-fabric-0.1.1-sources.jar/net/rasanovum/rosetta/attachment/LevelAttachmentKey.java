package net.rasanovum.rosetta.attachment;
import com.mojang.serialization.Codec;
import java.util.function.Supplier;
import net.minecraft.class_3218;
public final class LevelAttachmentKey<T> extends AttachmentKey<class_3218, T> {
    LevelAttachmentKey(String namespace, String path, Supplier<T> factory, Codec<T> codec) {
        super(AttachmentKind.LEVEL, namespace, path, factory, codec, false);
    }
}
