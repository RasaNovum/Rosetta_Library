package net.rasanovum.rosetta.nbt;

import net.minecraft.class_2487;
import net.minecraft.class_2499;

/** NBT accessors. */
public final class NbtCompat {
    private NbtCompat() {}

    public static byte getByte(class_2487 tag, String key, byte def) {
        //? if >=26.1 {
        /*return tag.getByteOr(key, def);
        *///?} else {
        return tag.method_10573(key, 99) ? tag.method_10571(key) : def;
        //?}
    }

    public static short getShort(class_2487 tag, String key, short def) {
        //? if >=26.1 {
        /*return tag.getShortOr(key, def);
        *///?} else {
        return tag.method_10573(key, 99) ? tag.method_10568(key) : def;
        //?}
    }

    public static int getInt(class_2487 tag, String key, int def) {
        //? if >=26.1 {
        /*return tag.getIntOr(key, def);
        *///?} else {
        return tag.method_10573(key, 99) ? tag.method_10550(key) : def;
        //?}
    }

    public static long getLong(class_2487 tag, String key, long def) {
        //? if >=26.1 {
        /*return tag.getLongOr(key, def);
        *///?} else {
        return tag.method_10573(key, 99) ? tag.method_10537(key) : def;
        //?}
    }

    public static float getFloat(class_2487 tag, String key, float def) {
        //? if >=26.1 {
        /*return tag.getFloatOr(key, def);
        *///?} else {
        return tag.method_10573(key, 99) ? tag.method_10583(key) : def;
        //?}
    }

    public static double getDouble(class_2487 tag, String key, double def) {
        //? if >=26.1 {
        /*return tag.getDoubleOr(key, def);
        *///?} else {
        return tag.method_10573(key, 99) ? tag.method_10574(key) : def;
        //?}
    }

    public static String getString(class_2487 tag, String key, String def) {
        //? if >=26.1 {
        /*return tag.getStringOr(key, def);
        *///?} else {
        return tag.method_10573(key, 8) ? tag.method_10558(key) : def;
        //?}
    }

    public static boolean getBoolean(class_2487 tag, String key, boolean def) {
        //? if >=26.1 {
        /*return tag.getBooleanOr(key, def);
        *///?} else {
        return tag.method_10545(key) ? tag.method_10577(key) : def;
        //?}
    }

    public static class_2487 getCompound(class_2487 tag, String key) {
        //? if >=26.1 {
        /*return tag.getCompoundOrEmpty(key);
        *///?} else {
        return tag.method_10573(key, 10) ? tag.method_10562(key) : new class_2487();
        //?}
    }

    public static class_2499 getList(class_2487 tag, String key, int elementType) {
        //? if >=26.1 {
        /*return tag.getListOrEmpty(key);
        *///?} else {
        return tag.method_10573(key, 9) ? tag.method_10554(key, elementType) : new class_2499();
        //?}
    }

    public static int[] getIntArray(class_2487 tag, String key) {
        //? if >=26.1 {
        /*return tag.getIntArray(key).orElse(new int[0]);
        *///?} else {
        return tag.method_10573(key, 11) ? tag.method_10561(key) : new int[0];
        //?}
    }

    public static long[] getLongArray(class_2487 tag, String key) {
        //? if >=26.1 {
        /*return tag.getLongArray(key).orElse(new long[0]);
        *///?} else {
        return tag.method_10573(key, 12) ? tag.method_10565(key) : new long[0];
        //?}
    }

    public static byte[] getByteArray(class_2487 tag, String key) {
        //? if >=26.1 {
        /*return tag.getByteArray(key).orElse(new byte[0]);
        *///?} else {
        return tag.method_10573(key, 7) ? tag.method_10547(key) : new byte[0];
        //?}
    }

    public static boolean contains(class_2487 tag, String key) {
        return tag.method_10545(key);
    }

    public static java.util.Set<String> getAllKeys(class_2487 tag) {
        //? if >=26.1 {
        /*return tag.keySet();
        *///?} else {
        return tag.method_10541();
        //?}
    }

    public static boolean hasUUID(class_2487 tag, String key) {
        //? if >=26.1 {
        /*return tag.getIntArray(key).map(arr -> arr.length == 4).orElse(false);
        *///?} else {
        return tag.method_25928(key);
        //?}
    }

    public static java.util.UUID getUUID(class_2487 tag, String key) {
        //? if >=26.1 {
        /*return tag.getIntArray(key)
                .filter(arr -> arr.length == 4)
                .map(net.minecraft.core.UUIDUtil::uuidFromIntArray)
                .orElse(null);
        *///?} else {
        return tag.method_25928(key) ? tag.method_25926(key) : null;
        //?}
    }

    public static void putUUID(class_2487 tag, String key, java.util.UUID uuid) {
        //? if >=26.1 {
        /*tag.putIntArray(key, net.minecraft.core.UUIDUtil.uuidToIntArray(uuid));
        *///?} else {
        tag.method_25927(key, uuid);
        //?}
    }

    public static class_2487 getCompound(class_2499 list, int index) {
        //? if >=26.1 {
        /*return list.getCompoundOrEmpty(index);
        *///?} else {
        return list.method_10602(index);
        //?}
    }

    public static String getString(class_2499 list, int index) {
        //? if >=26.1 {
        /*return list.getStringOr(index, "");
        *///?} else {
        return list.method_10608(index);
        //?}
    }

    public static int getInt(class_2499 list, int index, int def) {
        //? if >=26.1 {
        /*return list.getIntOr(index, def);
        *///?} else {
        return list.method_10600(index);
        //?}
    }
}
