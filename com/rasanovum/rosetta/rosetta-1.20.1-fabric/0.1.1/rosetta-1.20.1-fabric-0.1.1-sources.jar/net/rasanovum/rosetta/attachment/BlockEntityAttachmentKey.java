package net.rasanovum.rosetta.attachment;
import com.mojang.serialization.Codec;
import java.util.function.Supplier;
import net.minecraft.class_2586;
public final class BlockEntityAttachmentKey<T> extends AttachmentKey<class_2586, T> {
    BlockEntityAttachmentKey(String namespace, String path, Supplier<T> factory, Codec<T> codec) {
        super(AttachmentKind.BLOCK_ENTITY, namespace, path, factory, codec, false);
    }
}
