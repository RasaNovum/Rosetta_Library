package net.rasanovum.rosetta.attachment;
import com.mojang.serialization.Codec;
import java.util.function.Supplier;
import net.minecraft.class_1297;
public final class EntityAttachmentKey<T> extends AttachmentKey<class_1297, T> {
    EntityAttachmentKey(String namespace, String path, Supplier<T> factory, Codec<T> codec) {
        super(AttachmentKind.ENTITY, namespace, path, factory, codec, false);
    }
}
