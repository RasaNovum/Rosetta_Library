package net.rasanovum.rosetta.network;

import java.util.function.BiConsumer;
import java.util.function.Function;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

public record PacketDefinition<T extends RosettaPacket>(
        class_2960 id,
        Class<T> type,
        BiConsumer<T, class_2540> writer,
        Function<class_2540, T> reader,
        RosettaNetwork.PacketHandler<T> handler
) {}
