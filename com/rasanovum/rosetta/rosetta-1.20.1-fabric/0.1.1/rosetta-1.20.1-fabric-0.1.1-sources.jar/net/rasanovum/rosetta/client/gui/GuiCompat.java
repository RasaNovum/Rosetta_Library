package net.rasanovum.rosetta.client.gui;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_5481;
import net.minecraft.class_7833;

/** GUI drawing helpers. */
public class GuiCompat {

    private GuiCompat() {}

    public static void drawString(class_332 guiGraphics, class_327 font, String text, int x, int y, int color, boolean shadow) {
        //? if >=26.1 {
        /*guiGraphics.text(font, text, x, y, opaque(color), shadow);
        *///?} else {
        guiGraphics.method_51433(font, text, x, y, color, shadow);
        //?}
    }

    public static void drawString(class_332 guiGraphics, class_327 font, class_2561 text, int x, int y, int color, boolean shadow) {
        //? if >=26.1 {
        /*guiGraphics.text(font, text, x, y, opaque(color), shadow);
        *///?} else {
        guiGraphics.method_51439(font, text, x, y, color, shadow);
        //?}
    }

    public static void drawWidgetString(class_332 guiGraphics, class_339 widget, class_327 font, class_2561 text, int x, int y, int color, boolean shadow) {
        //? if >=26.1 {
        /*guiGraphics.text(font, text.copy().withStyle(style -> style.withColor(color & 0xFFFFFF)), x, y, opaque(color), shadow);
        *///?} else {
        guiGraphics.method_51439(font, text, x, y, color, shadow);
        //?}
    }

    public static void drawWidgetString(class_332 guiGraphics, class_339 widget, class_327 font, String text, int x, int y, int color, boolean shadow) {
        //? if >=26.1 {
        /*guiGraphics.text(font, Component.literal(text).withStyle(style -> style.withColor(color & 0xFFFFFF)), x, y, opaque(color), shadow);
        *///?} else {
        guiGraphics.method_51433(font, text, x, y, color, shadow);
        //?}
    }

    public static void drawString(class_332 guiGraphics, class_327 font, class_5481 text, int x, int y, int color, boolean shadow) {
        //? if >=26.1 {
        /*guiGraphics.text(font, text, x, y, opaque(color), shadow);
        *///?} else {
        guiGraphics.method_51430(font, text, x, y, color, shadow);
        //?}
    }

    public static void drawCenteredString(class_332 guiGraphics, class_327 font, class_2561 text, int x, int y, int color) {
        //? if >=26.1 {
        /*guiGraphics.text(font, text, x - font.width(text) / 2, y, opaque(color), false);
        *///?} else {
        guiGraphics.method_27534(font, text, x, y, color);
        //?}
    }

    public static void drawCenteredString(class_332 guiGraphics, class_327 font, String text, int x, int y, int color) {
        //? if >=26.1 {
        /*guiGraphics.text(font, text, x - font.width(text) / 2, y, opaque(color), false);
        *///?} else {
        guiGraphics.method_25300(font, text, x, y, color);
        //?}
    }

    public static void hLine(class_332 guiGraphics, int x1, int x2, int y, int color) {
        //? if >=26.1 {
        /*guiGraphics.horizontalLine(x1, x2, y, color);
        *///?} else {
        guiGraphics.method_25292(x1, x2, y, color);
        //?}
    }

    public static void vLine(class_332 guiGraphics, int x, int y1, int y2, int color) {
        //? if >=26.1 {
        /*guiGraphics.verticalLine(x, y1, y2, color);
        *///?} else {
        guiGraphics.method_25301(x, y1, y2, color);
        //?}
    }

    public static void renderOutline(class_332 guiGraphics, int x, int y, int width, int height, int color) {
        //? if >=26.1 {
        /*guiGraphics.outline(x, y, width, height, color);
        *///?} else {
        guiGraphics.method_49601(x, y, width, height, color);
        //?}
    }

    public static void blit(class_332 guiGraphics, class_2960 texture, int x, int y, int u, int v, int width, int height, int texWidth, int texHeight) {
        //? if >=26.1 {
        /*guiGraphics.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED, texture, x, y, u, v, width, height, texWidth, texHeight);
        *///?} else {
        guiGraphics.method_25290(texture, x, y, u, v, width, height, texWidth, texHeight);
        //?}
    }

    public static void blit(class_332 guiGraphics, class_2960 texture, int x, int y, int u, int v, int width, int height, int texWidth, int texHeight, int color) {
        //? if >=26.1 {
        /*guiGraphics.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED, texture, x, y, u, v, width, height, texWidth, texHeight, color);
        *///?} else {
        applyShaderColor(color);
        guiGraphics.method_25290(texture, x, y, u, v, width, height, texWidth, texHeight);
        resetShaderColor();
        //?}
    }

    public static void blit(class_332 guiGraphics, class_2960 texture, int x, int y, int width, int height, int u, int v, int uWidth, int vHeight, int texWidth, int texHeight) {
        //? if >=26.1 {
        /*guiGraphics.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED, texture, x, y, (float) u, (float) v, width, height, uWidth, vHeight, texWidth, texHeight);
        *///?} else {
        guiGraphics.method_25293(texture, x, y, width, height, u, v, uWidth, vHeight, texWidth, texHeight);
        //?}
    }

    public static void blit(class_332 guiGraphics, class_2960 texture, int x, int y, int width, int height, int u, int v, int uWidth, int vHeight, int texWidth, int texHeight, int color) {
        //? if >=26.1 {
        /*guiGraphics.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED, texture, x, y, (float) u, (float) v, width, height, uWidth, vHeight, texWidth, texHeight, color);
        *///?} else {
        applyShaderColor(color);
        guiGraphics.method_25293(texture, x, y, width, height, u, v, uWidth, vHeight, texWidth, texHeight);
        resetShaderColor();
        //?}
    }

    public static void renderTooltip(class_332 guiGraphics, class_327 font, class_2561 tooltip, int x, int y) {
        //? if >=26.1 {
        /*guiGraphics.setTooltipForNextFrame(font, tooltip, x, y);
        *///?} else {
        guiGraphics.method_51438(font, tooltip, x, y);
        //?}
    }

    public static void renderComponentTooltip(class_332 guiGraphics, class_327 font, List<class_2561> tooltip, int x, int y) {
        //? if >=26.1 {
        /*guiGraphics.setComponentTooltipForNextFrame(font, tooltip, x, y);
        *///?} else {
        guiGraphics.method_51434(font, tooltip, x, y);
        //?}
    }

    public static void renderComponentHoverEffect(class_332 guiGraphics, class_327 font, class_2583 style, int x, int y) {
        if (style == null || style.method_10969() == null) return;

        //? if >=26.1 {
        /*if (style.getHoverEvent() instanceof HoverEvent.ShowText showText) {
            guiGraphics.setTooltipForNextFrame(font, showText.value(), x, y);
        }
        *///?} else {
        guiGraphics.method_51441(font, style, x, y);
        //?}
    }

    public static class_2583 firstHoverStyle(class_2561 component) {
        for (class_2561 sibling : component.method_44746()) {
            class_2583 style = sibling.method_10866();
            if (style.method_10969() != null) return style;
        }
        return null;
    }

    public static void pushPose(class_332 guiGraphics) {
        //? if >=26.1 {
        /*guiGraphics.pose().pushMatrix();
        *///?} else {
        guiGraphics.method_51448().method_22903();
        //?}
    }

    public static void popPose(class_332 guiGraphics) {
        //? if >=26.1 {
        /*guiGraphics.pose().popMatrix();
        *///?} else {
        guiGraphics.method_51448().method_22909();
        //?}
    }

    public static void translate(class_332 guiGraphics, float x, float y) {
        //? if >=26.1 {
        /*guiGraphics.pose().translate(x, y);
        *///?} else {
        guiGraphics.method_51448().method_46416(x, y, 0);
        //?}
    }

    public static void scale(class_332 guiGraphics, float sx, float sy) {
        //? if >=26.1 {
        /*guiGraphics.pose().scale(sx, sy);
        *///?} else {
        guiGraphics.method_51448().method_22905(sx, sy, 1.0f);
        //?}
    }

    public static void rotateDegrees(class_332 guiGraphics, float degrees) {
        //? if >=26.1 {
        /*guiGraphics.pose().rotate((float) Math.toRadians(degrees));
        *///?} else {
        guiGraphics.method_51448().method_22907(class_7833.field_40718.rotationDegrees(degrees));
        //?}
    }

    public static void nextStratum(class_332 guiGraphics) {
        //? if >=26.1
        /*guiGraphics.nextStratum();*/
    }

    public static void enableBlend() {
        //? if <26.1
        com.mojang.blaze3d.systems.RenderSystem.enableBlend();
    }

    public static void disableBlend() {
        //? if <26.1
        com.mojang.blaze3d.systems.RenderSystem.disableBlend();
    }

    public static void setShaderColor(float r, float g, float b, float a) {
        //? if <26.1
        com.mojang.blaze3d.systems.RenderSystem.setShaderColor(r, g, b, a);
    }

    public static void defaultBlendFunc() {
        //? if <26.1
        com.mojang.blaze3d.systems.RenderSystem.defaultBlendFunc();
    }

    public static int argb(float r, float g, float b, float a) {
        int ai = Math.max(0, Math.min(255, Math.round(a * 255.0f)));
        int ri = Math.max(0, Math.min(255, Math.round(r * 255.0f)));
        int gi = Math.max(0, Math.min(255, Math.round(g * 255.0f)));
        int bi = Math.max(0, Math.min(255, Math.round(b * 255.0f)));
        return (ai << 24) | (ri << 16) | (gi << 8) | bi;
    }

    private static int withAlpha(int color, float alpha) {
        int sourceAlpha = (color >>> 24) & 0xFF;
        if (sourceAlpha == 0) sourceAlpha = 0xFF;
        int combinedAlpha = Math.max(0, Math.min(255, Math.round(sourceAlpha * alpha)));
        return (combinedAlpha << 24) | (color & 0xFFFFFF);
    }

    private static int opaque(int color) {
        return ((color >>> 24) & 0xFF) == 0 ? color | 0xFF000000 : color;
    }

    private static void applyShaderColor(int color) {
        float a = ((color >>> 24) & 0xFF) / 255.0f;
        float r = ((color >>> 16) & 0xFF) / 255.0f;
        float g = ((color >>> 8) & 0xFF) / 255.0f;
        float b = (color & 0xFF) / 255.0f;
        enableBlend();
        setShaderColor(r, g, b, a);
    }

    private static void resetShaderColor() {
        setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
        disableBlend();
    }
}
