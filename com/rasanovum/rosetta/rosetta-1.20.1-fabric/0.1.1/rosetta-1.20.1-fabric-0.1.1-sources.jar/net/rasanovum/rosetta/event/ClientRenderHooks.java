package net.rasanovum.rosetta.event;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.class_1657;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4604;
import net.minecraft.class_638;

/** Loader-neutral HUD and world render callbacks. */
public final class ClientRenderHooks {
    private static final List<Callbacks> CALLBACKS = new CopyOnWriteArrayList<>();

    private ClientRenderHooks() {}

    public static void register(Callbacks callbacks) {
        if (callbacks == null) throw new IllegalArgumentException("callbacks cannot be null");
        CALLBACKS.add(callbacks);
    }

    public static void renderHud(class_332 graphics, float tickDelta) {
        CALLBACKS.forEach(c -> c.renderHud(graphics, tickDelta));
    }

    public static void renderWorld(class_4587 poseStack, class_638 level, class_1657 player, float tickDelta, class_4604 frustum) {
        CALLBACKS.forEach(c -> c.renderWorld(poseStack, level, player, tickDelta, frustum));
    }

    public interface Callbacks {
        default void renderHud(class_332 graphics, float tickDelta) {}
        default void renderWorld(class_4587 poseStack, class_638 level, class_1657 player, float tickDelta, class_4604 frustum) {}
    }
}
