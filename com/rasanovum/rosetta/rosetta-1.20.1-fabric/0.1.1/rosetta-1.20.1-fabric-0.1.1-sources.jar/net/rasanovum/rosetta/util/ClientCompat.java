package net.rasanovum.rosetta.util;

import net.minecraft.class_1043;
import net.minecraft.class_1060;
import net.minecraft.class_1657;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;

/** Client-side helpers. */
public final class ClientCompat {
    private ClientCompat() {}

    public static class_2960 getPlayerSkin(class_310 minecraft, class_1657 player) {
        //? if <1.21 {
        return minecraft.method_1582().method_44705(player.method_7334());
        //?} else {
        /*//? if >=26.1 {
        /^return ((AbstractClientPlayer) player).getSkin().body().texturePath();
        ^///?} else {
        return minecraft.getSkinManager().getInsecureSkin(player.getGameProfile()).texture();
        //?}
        *///?}
    }

    public static class_1043 dynamicTexture(String label, net.minecraft.class_1011 image) {
        //? if >=26.1 {
        /*return new DynamicTexture(() -> label, image);
        *///?} else {
        return new class_1043(image);
        //?}
    }

    public static class_2960 registerTexture(class_1060 textureManager, String namespace, String label, class_1043 texture) {
        //? if >=26.1 {
        /*ResourceLocation id = RegistryCompat.getLocation(namespace, label);
        textureManager.register(id, texture);
        return id;
        *///?} else {
        return textureManager.method_4617(label, texture);
        //?}
    }

    public static int nativeImageGetPixel(net.minecraft.class_1011 image, int x, int y) {
        //? if >=26.1 {
        /*return image.getPixel(x, y);
        *///?} else {
        return image.method_4315(x, y);
        //?}
    }

    public static void nativeImageSetPixel(net.minecraft.class_1011 image, int x, int y, int color) {
        //? if >=26.1 {
        /*image.setPixel(x, y, color);
        *///?} else {
        image.method_4305(x, y, color);
        //?}
    }

    public static long windowHandle(net.minecraft.class_1041 window) {
        //? if >=26.1 {
        /*return window.handle();
        *///?} else {
        return window.method_4490();
        //?}
    }

    public static net.minecraft.class_243 cameraPosition(net.minecraft.class_4184 camera) {
        //? if >=26.1 {
        /*return camera.position();
        *///?} else {
        return camera.method_19326();
        //?}
    }

    public static void putVertex(class_4587.class_4665 pose, class_4588 consumer, float x, float y, float z, int red, int green, int blue, int alpha) {
        //? if <1.21 {
        consumer.method_22918(pose.method_23761(), x, y, z).method_1336(red, green, blue, alpha).method_1344();
        //?} else {
        /*consumer.addVertex(pose, x, y, z).setColor(red, green, blue, alpha);
        *///?}
    }
}
