package net.rasanovum.rosetta.event;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_5944;

/** Legacy core-shader registration without a direct Fabric API dependency. */
public final class ClientShaderHooks {
    private static final List<Registration> REGISTRATIONS = new CopyOnWriteArrayList<>();

    private ClientShaderHooks() {}

    public static void register(Registration registration) { REGISTRATIONS.add(registration); }

    public static void registerShaders(Registrar registrar) throws IOException {
        for (Registration registration : REGISTRATIONS) registration.register(registrar);
    }

    @FunctionalInterface
    public interface Registration {
        void register(Registrar registrar) throws IOException;
    }

    @FunctionalInterface
    public interface Registrar {
        void register(class_2960 id, class_293 format, Consumer<class_5944> onLoad) throws IOException;
    }
}
//?} else {
/*public final class ClientShaderHooks {
    private ClientShaderHooks() {}
}
*///?}
