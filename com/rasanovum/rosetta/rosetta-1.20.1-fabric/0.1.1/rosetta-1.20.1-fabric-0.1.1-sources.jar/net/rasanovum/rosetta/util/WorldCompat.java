package net.rasanovum.rosetta.util;

/** World and chunk helpers. */
public final class WorldCompat {
    private WorldCompat() {}

    public static long chunkPosAsLong(int chunkX, int chunkZ) {
        //? if >=26.1 {
        /*return net.minecraft.world.level.ChunkPos.pack(chunkX, chunkZ);
        *///?} else {
        return net.minecraft.class_1923.method_8331(chunkX, chunkZ);
        //?}
    }

    public static int chunkX(net.minecraft.class_1923 pos) {
        //? if >=26.1 {
        /*return pos.x();
        *///?} else {
        return pos.field_9181;
        //?}
    }

    public static int chunkZ(net.minecraft.class_1923 pos) {
        //? if >=26.1 {
        /*return pos.z();
        *///?} else {
        return pos.field_9180;
        //?}
    }

    public static long chunkPosToLong(net.minecraft.class_1923 pos) {
        //? if >=26.1 {
        /*return pos.pack();
        *///?} else {
        return pos.method_8324();
        //?}
    }

    public static int minBuildHeight(net.minecraft.class_5539 level) {
        //? if >=26.1 {
        /*return level.getMinY();
        *///?} else {
        return level.method_31607();
        //?}
    }

    public static net.minecraft.class_1923 chunkPosFromBlockPos(net.minecraft.class_2338 pos) {
        //? if >=26.1 {
        /*return new net.minecraft.world.level.ChunkPos(pos.getX() >> 4, pos.getZ() >> 4);
        *///?} else {
        return new net.minecraft.class_1923(pos);
        //?}
    }

    public static int maxBuildHeight(net.minecraft.class_5539 level) {
        //? if >=26.1 {
        /*return level.getMaxY() + 1;
        *///?} else {
        return level.method_31600();
        //?}
    }
}
