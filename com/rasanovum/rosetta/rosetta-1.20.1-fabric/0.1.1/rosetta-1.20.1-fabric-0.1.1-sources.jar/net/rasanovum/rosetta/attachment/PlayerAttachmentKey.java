package net.rasanovum.rosetta.attachment;
import com.mojang.serialization.Codec;
import java.util.function.Supplier;
import net.minecraft.class_3222;
public final class PlayerAttachmentKey<T> extends AttachmentKey<class_3222, T> {
    PlayerAttachmentKey(String namespace, String path, boolean copyOnRespawn, Supplier<T> factory, Codec<T> codec) {
        super(AttachmentKind.PLAYER, namespace, path, factory, codec, copyOnRespawn);
    }
}
