package net.rasanovum.rosetta.loaders.fabric.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.class_1923;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.rasanovum.rosetta.event.ServerHooks;

@Pseudo
@Mixin(targets = "net.minecraft.server.network.PlayerChunkSender")
public abstract class PlayerChunkSenderMixin {
    //? if <1.21 {
    /*
    *///?} else {
    @Inject(
            method = "sendChunk",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/server/network/ServerGamePacketListenerImpl;send(Lnet/minecraft/network/protocol/Packet;)V",
                    shift = At.Shift.AFTER))
    private static void rosetta$chunkSent(class_3244 connection, class_3218 level,
                                          class_2818 chunk, CallbackInfo callbackInfo) {
        ServerHooks.chunkSent(connection.field_14140, level, chunk);
    }

    @Inject(
            method = "dropChunk",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/server/network/ServerGamePacketListenerImpl;send(Lnet/minecraft/network/protocol/Packet;)V",
                    shift = At.Shift.AFTER))
    private static void rosetta$chunkUnwatched(class_3222 player, class_1923 pos, CallbackInfo callbackInfo) {
        ServerHooks.chunkUnwatched(player, (class_3218) player.method_37908(), pos);
    }
    //?}
}
