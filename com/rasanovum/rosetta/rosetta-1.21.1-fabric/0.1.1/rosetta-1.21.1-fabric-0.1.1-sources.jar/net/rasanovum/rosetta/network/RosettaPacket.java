package net.rasanovum.rosetta.network;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
//?}
import net.minecraft.class_8710;

/** Marker interface for a packet registered through {@link RosettaNetwork}. */
public interface RosettaPacket
        //? if >=1.21
        extends class_8710
{
    //? if >=1.21 {
    Map<Class<?>, class_9154<?>> TYPE_CACHE = new ConcurrentHashMap<>();

    @Override
    default class_9154<? extends class_8710> method_56479() {
        class_9154<?> type = TYPE_CACHE.get(getClass());
        if (type == null) {
            throw new IllegalStateException("Packet type was not registered: " + getClass().getName());
        }
        return type;
    }

    static <T extends RosettaPacket> void registerType(Class<T> clazz, class_9154<T> type) {
        class_9154<?> previous = TYPE_CACHE.putIfAbsent(clazz, type);
        if (previous != null && !previous.equals(type)) {
            throw new IllegalArgumentException("Packet class was registered twice: " + clazz.getName());
        }
    }
    //?}
}
