package net.rasanovum.rosetta.util;

import net.minecraft.class_2960;

/** Identifier and registry helpers. */
public final class RegistryCompat {
    private RegistryCompat() {}

    public static class_2960 getLocation(String location) {
        //? if <1.21 {
        /*return new ResourceLocation(location);
        *///?} else {
        return class_2960.method_60654(location);
        //?}
    }

    public static class_2960 getLocation(String base, String path) {
        //? if <1.21 {
        /*return new ResourceLocation(base, path);
        *///?} else {
        return class_2960.method_60654(base + ":" + path);
        //?}
    }

    public static net.minecraft.class_4970.class_2251 blockProperties(
            class_2960 id,
            net.minecraft.class_4970.class_2251 properties
    ) {
        //? if >=26.1 {
        /*return properties.setId(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.BLOCK, id));
        *///?} else {
        return properties;
        //?}
    }

    public static net.minecraft.class_1792.class_1793 itemProperties(
            class_2960 id,
            net.minecraft.class_1792.class_1793 properties
    ) {
        //? if >=26.1 {
        /*return properties.setId(net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.ITEM, id));
        *///?} else {
        return properties;
        //?}
    }

    public static <T> T registryGet(net.minecraft.class_2378<T> registry, class_2960 id) {
        //? if >=26.1 {
        /*return registry.getValue(id);
        *///?} else {
        return registry.method_10223(id);
        //?}
    }

    public static class_2960 keyLocation(net.minecraft.class_5321<?> key) {
        //? if >=26.1 {
        /*return key.identifier();
        *///?} else {
        return key.method_29177();
        //?}
    }
}
