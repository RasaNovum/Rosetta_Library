package net.rasanovum.rosetta.util;
//? if >=26.1 {
/*import net.minecraft.server.permissions.Permission;
import net.minecraft.server.permissions.PermissionLevel;
*///?}

import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_167;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8779;
import net.minecraft.server.MinecraftServer;
import net.rasanovum.rosetta.Rosetta;

/** Player and entity helpers. */
public final class EntityCompat {
    private EntityCompat() {}

    public static MinecraftServer getPlayerServer(class_3222 player) {
        //? if >=26.1 {
        /*return player.level().getServer();
        *///?} else {
        return player.field_13995;
        //?}
    }

    public static class_3218 getPlayerServerLevel(class_3222 player) {
        //? if >=26.1 {
        /*return player.level();
        *///?} else {
        return player.method_51469();
        //?}
    }

    public static void awardAdvancement(class_3222 player, String advancementId) {
        try {
            //? if <1.21 {
            /*Advancement advancement = player.server.getAdvancements().getAdvancement(new net.minecraft.resources.ResourceLocation(advancementId));
            if (advancement != null) {
                AdvancementProgress progress = player.getAdvancements().getOrStartProgress(advancement);
                if (!progress.isDone()) for (String criterion : progress.getRemainingCriteria()) player.getAdvancements().award(advancement, criterion);
            }
            *///?} else {
            class_8779 advancement = getPlayerServer(player).method_3851().method_12896(RegistryCompat.getLocation(advancementId));
            if (advancement != null) {
                class_167 progress = player.method_14236().method_12882(advancement);
                if (!progress.method_740()) {
                    boolean grantedAny = false;
                    for (String criterion : progress.method_731()) {
                        if (player.method_14236().method_12878(advancement, criterion)) grantedAny = true;
                    }
                    if (grantedAny) {
                        //? if >=26.1 {
                        /*player.getAdvancements().flushDirty(player, false);
                        *///?} else {
                        player.method_14236().method_12876(player);
                        //?}
                    }
                }
            }
            //?}
        } catch (Exception e) {
            Rosetta.LOGGER.warn("Failed to award advancement {} to player {}: {}", advancementId, player.method_5477().getString(), e.getMessage());
        }
    }

    public static boolean hasPermission(class_1657 player, int requiredLevel) {
        //? if >=26.1 {
        /*return player.permissions().hasPermission(new Permission.HasCommandLevel(PermissionLevel.byId(requiredLevel)));
        *///?} else {
        return player.method_5687(requiredLevel);
        //?}
    }

    public static boolean hasPermission(net.minecraft.class_2168 source, int requiredLevel) {
        //? if >=26.1 {
        /*return source.permissions().hasPermission(new Permission.HasCommandLevel(PermissionLevel.byId(requiredLevel)));
        *///?} else {
        return source.method_9259(requiredLevel);
        //?}
    }

    public static void displayClientMessage(class_1657 player, class_2561 message, boolean actionBar) {
        //? if >=26.1 {
        /*if (actionBar) player.sendOverlayMessage(message);
        else player.sendSystemMessage(message);
        *///?} else {
        player.method_7353(message, actionBar);
        //?}
    }

    public static boolean startRiding(class_1297 rider, class_1297 vehicle, boolean force) {
        //? if >=26.1 {
        /*return rider.startRiding(vehicle, force, false);
        *///?} else {
        return rider.method_5873(vehicle, force);
        //?}
    }

    public static boolean isItemOnCooldown(class_1657 player, net.minecraft.class_1792 item, net.minecraft.class_1799 stack) {
        //? if >=26.1 {
        /*return player.getCooldowns().isOnCooldown(stack);
        *///?} else {
        return player.method_7357().method_7904(item);
        //?}
    }

    public static void teleportTo(class_1297 entity, net.minecraft.class_3218 level, double x, double y, double z, float yRot, float xRot) {
        //? if >=26.1 {
        /*entity.teleportTo(level, x, y, z, java.util.Set.of(), yRot, xRot, false);
        *///?}
        //? if <26.1
        entity.method_48105(level, x, y, z, java.util.Set.of(), yRot, xRot);
    }
}
